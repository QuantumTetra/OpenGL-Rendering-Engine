#pragma once

#include <unordered_map>
#include <vector>
#include <string>

class BlockBase {
public:
	int rotation = 0;
	int type = -1;
	std::unordered_map<std::string, int> ints;
	std::unordered_map<std::string, double> doubles;
	std::unordered_map<std::string, std::string> strings;

	int textureID = -1;
	int renderID = -1;

	BlockBase() {}
	BlockBase(int rotation, int type, int textureID, int renderID) : rotation(rotation), type(type), textureID(textureID), renderID(renderID) {}

	void addInt(const std::string& name, int value) {
		ints[name] = value;
	}

	void editInt(const std::string& name, int value) {
		if (ints.find(name) != ints.end()) {
			ints[name] = value;
		}
	}

	int getInt(const std::string& name) {
		if (ints.find(name) != ints.end()) {
			return ints[name];
		}
		return 0;
	}

	void eraseInt(const std::string& name) {
		if (ints.find(name) != ints.end()) {
			ints.erase(name);
		}
	}

	//double
	void addDouble(const std::string& name, double value) {
		doubles[name] = value;
	}

	void editDouble(const std::string& name, double value) {
		if (doubles.find(name) != doubles.end()) {
			doubles[name] = value;
		}
	}

	double getDouble(const std::string& name) {
		if (doubles.find(name) != doubles.end()) {
			return doubles[name];
		}
		return 0.0;
	}

	void eraseDouble(const std::string& name) {
		if (doubles.find(name) != doubles.end()) {
			doubles.erase(name);
		}
	}

	//string
	void addString(const std::string& name, std::string& value) {
		strings[name] = value;
	}

	void editString(const std::string& name, std::string& value) {
		if (strings.find(name) != strings.end()) {
			strings[name] = value;
		}
	}

	std::string& getString(const std::string& name) {
		if (strings.find(name) != strings.end()) {
			return strings[name];
		}
		return std::string("");
	}
};

class ShipBase {
public:
	std::vector<std::vector<BlockBase*>*>* blocks = nullptr;
	int type = -1;
	int length = 100;
	int width = 100;
	ShipBase() {
		type = 0;
		length = 100;
		width = 100;
	}
	ShipBase(int type, int length, int width) : type(type), length(length), width(width) {

	}
	std::vector<ShipBase*>* parseShips(std::string& file) const;
	~ShipBase() {
		if (blocks != nullptr) {
			for (int i = 0; i < blocks->size(); i++) {
				delete (*blocks)[i];
			}
			delete blocks;
		}
	}
	void deleteShipVector(std::vector<ShipBase*>* ships) {
		if (ships != nullptr) {
			for (int i = 0; i < ships->size(); i++) {
				delete (*ships)[i];
			}
			delete ships;
		}
	}
};

