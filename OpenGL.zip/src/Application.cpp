#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <math.h>
#include <thread>
#include <filesystem>

#include "Renderer.h"

#include "VertexBuffer.h"
#include "VertexBufferLayout.h"
#include "IndexBuffer.h"
#include "VertexArray.h"
#include "Shader.h"
#include "Texture.h"

//includes that allow us to write actual code in another area
#include "ThreadInterface.h"
#include "Application.h"

#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"

#include "imgui\imgui.h"
#include "imgui\imgui_impl_glfw_gl3.h"

class Object {
public:
	int m_CompID;

	Texture* texture;
	VertexArray* va;
	IndexBuffer* ib;
	VertexBufferLayout* layout;
	VertexBuffer* vb;

	float width = 0.0f;
	float height = 0.0f;

	float positions[16];
	unsigned int indices[6];
	
	float x = 0.0f;
	float y = 0.0f;
	float r = 0.0f;

	Object(const std::string& texturePath, float scale, int CompID) {
		m_CompID = CompID;
		texture = new Texture(texturePath);
		width = float(texture->GetWidth()) * scale;
		height = float(texture->GetHeight()) * scale;

		float p2[] = {
			-1.0f * width, -1.0f * height, 0.0f, 0.0f, // 0
			 1.0f * width, -1.0f * height, 1.0f, 0.0f, // 1
			 1.0f * width,  1.0f * height, 1.0f, 1.0f, // 2
			-1.0f * width,  1.0f * height, 0.0f, 1.0f  // 3
		};

		for (int i = 0; i < 16; i++) {
			positions[i] = p2[i];
		}

		unsigned int i2[] = {
			0, 1, 2,
			2, 3, 0
		};

		for (int i = 0; i < 6; i++) {
			indices[i] = i2[i];
		}

		va = new VertexArray();
		
		vb = new VertexBuffer(positions, 4 * 4 * sizeof(float));
		layout = new VertexBufferLayout();
		layout->Push<float>(2);
		layout->Push<float>(2);
		va->AddBuffer(*vb, *layout);

		ib = new IndexBuffer(indices, 6);

		GLCall(glBindBuffer(GL_ARRAY_BUFFER, 0));
		GLCall(glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0));
	}
	Object(Texture* texture, float scale, int CompID) {
		m_CompID = CompID;
		this->texture = texture;
		width = float(texture->GetWidth()) * scale;
		height = float(texture->GetHeight()) * scale;

		float p2[] = {
			-1.0f * width, -1.0f * height, 0.0f, 0.0f, // 0
			1.0f * width, -1.0f * height, 1.0f, 0.0f, // 1
			1.0f * width,  1.0f * height, 1.0f, 1.0f, // 2
			-1.0f * width,  1.0f * height, 0.0f, 1.0f  // 3
		};

		for (int i = 0; i < 16; i++) {
			positions[i] = p2[i];
		}

		unsigned int i2[] = {
			0, 1, 2,
			2, 3, 0
		};

		for (int i = 0; i < 6; i++) {
			indices[i] = i2[i];
		}

		va = new VertexArray();

		vb = new VertexBuffer(positions, 4 * 4 * sizeof(float));
		layout = new VertexBufferLayout();
		layout->Push<float>(2);
		layout->Push<float>(2);
		va->AddBuffer(*vb, *layout);

		ib = new IndexBuffer(indices, 6);

		GLCall(glBindBuffer(GL_ARRAY_BUFFER, 0));
		GLCall(glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0));
	}
	~Object() {
		//delete texture;
		delete va;
		delete ib;
		delete layout;
		delete vb;
	}
	void RenderObject(glm::mat4& proj, glm::mat4& view, Renderer& renderer, Shader& shader) {
		IndexBuffer ib(indices, 6);

		GLCall(glBindBuffer(GL_ARRAY_BUFFER, 0));
		GLCall(glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0));

		texture->Bind();

		glm::mat4 model = glm::translate(glm::mat4(1.0f), glm::vec3(x, y, 0.0f)); //positon

		model = glm::rotate(model, r, glm::vec3(0.0f, 0.0f, 1.0f)); //rotating our positon matrix, perfect everything we need

		shader.Bind();
		shader.SetUniformMat4f("u_Model", model);
		shader.SetUniformMat4f("u_Proj", proj);
		shader.SetUniformMat4f("u_View", view);
		//like that /\
		//accept that multiplication should be done in shader

		renderer.Draw(*va, ib, shader);
	}
};

Object* findObjectWithID(int ID, std::vector<Object*>& objs) {
	Object* r_Obj = nullptr;
	for (Object* o : objs) {
		if (o->m_CompID == ID) {
			r_Obj = o;
			break;
		}
	}
	return r_Obj;
}

void eraseSubStr(std::string & mainStr, const std::string & toErase) {
	// Search for the substring in string
	size_t pos = mainStr.find(toErase);

	if (pos != std::string::npos) {
		// If found then erase it from string
		mainStr.erase(pos, toErase.length());
	}
}

std::vector<std::string*>* parseFile(const char* file) {
	std::ifstream inFile(file);
	if (!inFile) {
		std::cout << file << " failed" << std::endl;
		return nullptr;
	}
	//std::cout << "WORKED" << std::endl;
	std::vector<std::string*>* text = new std::vector<std::string*>;
	// one line
	//std::string line;
	char data[100];
	// extract all the text from the input file
	//std::cout << "FILE SUCCESS" << std::endl;
	while (inFile.getline(data, 100)) {
		// store each line in the vector
		std::string* texts = new std::string(data);
		//std::cout << *texts << std::endl;
		text->emplace_back(texts);
	}
	return text;
}

void loadFileNames(std::vector<std::string*>& fileNames) {
	std::vector<std::string*>* strings = parseFile("res/textures/Material_Master_List.txt");
	const std::string newLine("\n");

	for (std::string* string : (*strings)) {
		if (string->find("file_name=") != std::string::npos) {
			fileNames.emplace_back(new std::string(string->substr(10)));
			eraseSubStr(*(fileNames[fileNames.size() - 1]), newLine);
		}
	}

	if (strings != nullptr) {
		for (int i = 0; i < strings->size(); i++) {
			//std::cout << *((*strings)[i]) << std::endl;
			delete (*strings)[i];
			std::cout << "deleting" << std::endl;
		}
		delete strings;
	}
}

void loadTextures(std::vector<Texture*>& materials) {
	std::vector<std::string*> fileNames;
	loadFileNames(fileNames);

	std::string filePath("res/textures/");

	for (std::string* string : fileNames) {
		Texture* texture = new Texture(filePath + *string);
		materials.emplace_back(texture);
	}

	for (int i = 0; i < fileNames.size(); i++) {
		//std::cout << *(fileNames[i]) << std::endl;
		delete (fileNames)[i];
		std::cout << "deleting" << std::endl;
	}
	fileNames.clear();
}

void keyCheck(GLFWwindow* window, bool (keys[256])) {
	if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) keys[0] = true;
	else keys[0] = false;
}

void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods) {
	std::cout << "Key pressed: " << key << std::endl;
}

static void cursor_position_callback(GLFWwindow* window, double xpos, double ypos) {
	std::cout << "cursor is at: " << xpos << " " << ypos << std::endl;
}

void mouse_button_callback(GLFWwindow* window, int button, int action, int mods) {
	if (button == GLFW_MOUSE_BUTTON_RIGHT && action == GLFW_PRESS);
	std::cout << "mouse button pressed: " << button << std::endl;

}

void scroll_callback(GLFWwindow* window, double xoffset, double yoffset) {
	std::cout << "scroll wheel moved: " << xoffset << " " << yoffset << std::endl;
}

int graphicsThread(int width, int height, ThreadInterface* Interface) {
	float PI = atan(1.0f) * 4.0f;

	bool fullscreen = false;
	bool Vsync = true;

	std::cout << PI;
	std::cout << std::endl;

	GLFWwindow* window;

	std::cout << "[INFO]::[INFO]:: Size of window in byte is: " << sizeof(window) << std::endl;

	/*Initialize the library */
	if (!glfwInit())
		return -1;

	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	window = glfwCreateWindow(width, height, "Game", NULL, NULL);
	if (!window) {
		glfwTerminate();
		return -1;
	}

	/* make the window's context current */
	glfwMakeContextCurrent(window);

	/* makes the window un-resizable */
	glfwWindowHint(GLFW_RESIZABLE, GL_FALSE);

	const GLFWvidmode* mode = glfwGetVideoMode(glfwGetPrimaryMonitor());
	if (fullscreen) {
		// sets window to primary monitor and is in fullscreen mode, getting refresh rate of monitor 
		glfwSetWindowMonitor(window, glfwGetPrimaryMonitor(), 0, 0, mode->width, mode->height, mode->refreshRate);
		width = mode->width;
		height = mode->height;
	}
	else {
		// sets window to simply be in windowed mode, refresh rate ignored 
		glfwSetWindowMonitor(window, NULL, mode->width / 2 - width / 2, mode->height / 2 - height / 2, width, height, 144);
	}

	//enables V-sync
	if (Vsync) glfwSwapInterval(1);

	/* sets windows size finally */
	glfwSetWindowSize(window, width, height);

	// \/ all the key stuffs/cursor/mouse stuffs \/
	glfwSetKeyCallback(window, key_callback);

	glfwSetMouseButtonCallback(window, mouse_button_callback);

	glfwSetCursorPosCallback(window, cursor_position_callback);

	glfwSetScrollCallback(window, scroll_callback);
	// /\ keys/mouse stuff /\

	if (glewInit() != GLEW_OK) {
		std::cout << "[ERROR]::[GLEW]: GLEW did not initialize, quiting" << std::endl;
		glfwSetWindowShouldClose(window, true);
	}

	std::cout << glGetString(GL_VERSION) << std::endl;

	std::vector<Texture*>* materials = new std::vector<Texture*>;

	{
		ThreadInterface* interface = Interface;
		std::unordered_map<std::string, int> materialPointers;
		std::vector<Object*> objects;

		loadTextures(*materials);

		float positions[] = {
			-240.0f, -135.5f, 0.0f, 0.0f, // 0
			 240.5f, -135.5f, 1.0f, 0.0f, // 1
			 240.5f,  135.5f, 1.0f, 1.0f, // 2
			-240.5f,  135.5f, 0.0f, 1.0f  // 3
		};

		unsigned int indices[] = {
			0, 1, 2,
			2, 3, 0
		};

		//not temp, lol
		GLCall(glEnable(GL_BLEND));
		GLCall(glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA));

		/*VertexArray va;
		VertexBuffer vb(positions, 4 * 4 * sizeof(float));

		VertexBufferLayout layout;
		layout.Push<float>(2);
		layout.Push<float>(2);
		va.AddBuffer(vb, layout);*/

		//IndexBuffer ib(indices, 6);

		glm::mat4 proj = glm::ortho(0.0f, float(width), 0.0f, float(height), -1.0f, 1.0f); //projection
		glm::mat4 view = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.0f, 0.0f)); //camera

		Shader shader("res/shaders/Basic.shader");
		shader.Bind();
		shader.SetUniform4f("u_Color", 0.8f, 0.3f, 0.8f, 1.0f);
		shader.SetUniformMat4f("u_Proj", proj);
		shader.SetUniformMat4f("u_View", view);
		shader.SetUniform1i("u_Texture", 0);

		/*Texture texture("res/textures/planet.png");
		texture.Bind();*/

		/*Texture texture2("res/textures/Falcon.png");
		texture2.Bind();*/

		//va.Unbind();
		shader.Unbind();
		//vb.Unbind();
		//ib.Unbind();

		GLCall(glBindBuffer(GL_ARRAY_BUFFER, 0));
		GLCall(glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0));

		Renderer renderer;

		ImGui::CreateContext();
		ImGui_ImplGlfwGL3_Init(window, true);

		ImGui::StyleColorsDark();

		float x = 0.0f;
		float y = 0.0f;

		float r = 0.0f;

		//Object object1("res/textures/planet.png", 0.125, interface->generateNewObjectID());
		objects.emplace_back(new Object((*materials)[0], 0.5, interface->generateNewObjectID()));
		objects[0]->x = 300.0f;
		objects[0]->y = 200.0f;

		std::cout << "Materials size: " << materials->size() << std::endl;
		//std::cout << "First material pointer: " << (*materials)[0] << std::endl;

		/* Loop until user closes window */
		while (!glfwWindowShouldClose(window)) {

			//checking if key is pressed, setup a key checker function above
			int state = glfwGetKey(window, GLFW_KEY_E);
			if (state == GLFW_PRESS)
				std::cout << "E pressed" << std::endl;

			//used for thread sync
			if (interface->frame) {
				interface->frame = false;
			}
			else {
				interface->frame = true;
			}

			//these two need to happen at start of each cycle
			renderer.Clear();
			ImGui_ImplGlfwGL3_NewFrame();
			//now we can do ImGui code
			/*
			//do this for each and every object in future
			//when we draw we will generate a model matrice from the objects pos and rotation and send it to the shader
			//then render
			//also remeber to bind the correct texture
			glm::mat4 model = glm::translate(glm::mat4(1.0f), glm::vec3(x, y, 0.0f)); //positon

			model = glm::rotate(model, glm::radians(r), glm::vec3(0.0f, 0.0f, 1.0f));//rotating our positon matrix, perfect everything we need

			shader.Bind();
			shader.SetUniformMat4f("u_Model", model);
			//like that /\
						//accept that multiplication should be done in shader
			texture.Bind();
			//renderer.Draw(va, ib, shader);

			model = glm::translate(glm::mat4(1.0f), glm::vec3(x + 100.0f, y + 100.0f, 0.0f)); //positon

			model = glm::rotate(model, glm::radians(r), glm::vec3(0.0f, 0.0f, 1.0f));//rotating our positon matrix, perfect everything we need

			shader.Bind();
			shader.SetUniformMat4f("u_Model", model);
			//like that /\
									//accept that multiplication should be done in shader
			texture2.Bind();
			//renderer.Draw(va, ib, shader);
			*/
			for (Object* object : objects) {
				object->RenderObject(proj, view, renderer, shader);
			}

			//our gui for our other window goes here:
			{
				ImGui::Text("testing");
				/*ImGui::SliderFloat("X", &x, 0.0f, 640.0f);
				ImGui::SliderFloat("Y", &y, 0.0f, 480.0f);
				ImGui::SliderFloat("R", &r, 0.0f, 360.0f);*/
				ImGui::Text("Application average %.3f ms/frame (%.1f FPS)", 1000.0f / ImGui::GetIO().Framerate, ImGui::GetIO().Framerate); //useful as fuck
			}
			//draw out gui
			ImGui::Render();
			ImGui_ImplGlfwGL3_RenderDrawData(ImGui::GetDrawData());
			/* Swap front and back buffers */
			glfwSwapBuffers(window);

			/* Poll for and process events */
			glfwPollEvents();

			//below this will be the code that deals with data back and forth to manager
			//this will ask if there are any creation requests and proccess them
			
			if (interface->createRequests.size() > 0) {
				std::vector<CreateGraphicsObjectRequest*> createRequests;
				for (int i = 0; i < interface->createRequests.size(); i++) {
					createRequests.emplace_back(interface->createRequests[i]);
				}

				for (CreateGraphicsObjectRequest* request : createRequests) {
					/*
					we need to check to seeif the requests id returns an actual texture
					*/
					if (request->textureID < materials->size() && request->textureID > -1) {
						objects.emplace_back(new Object((*materials)[request->textureID], request->scale, request->ID));
					}
					else {
						std::cout << "[ERROR]::[WARN]: Object's texture ID does not exist, replacing with missing texture" << std::endl;
						objects.emplace_back(new Object((*materials)[0], request->scale, request->ID));
					}
				}

				for (int i = 0; i < interface->createRequests.size(); i++) {
					delete interface->createRequests[i];
				}
				for (int i = 0; i < createRequests.size(); i++) {
					delete createRequests[i];
				}
				createRequests.clear();
				interface->createRequests.erase(interface->createRequests.begin(), interface->createRequests.begin() + createRequests.size());
				std::cout << "Added new object" << std::endl;
				std::cout << "Current Objects:" << std::endl;

				for (int i = 0; i < objects.size(); i++) {
					std::cout << objects[i]->m_CompID << std::endl;
				}
				objects[1]->x = 300;
				objects[1]->y = 200;
			}

			if (interface->positionChanges.size() > 0) {
				std::vector<PosChangeRequest*> posRequests;
				for (int i = 0; i < interface->positionChanges.size(); i++) {
					posRequests.emplace_back(interface->positionChanges[i]);
				}

				for (PosChangeRequest* p : posRequests) {
					Object* o = findObjectWithID(p->ID, objects);
					if (o != nullptr) {
						o->x = p->x;
						o->y = p->y;
						o->r = p->r;
					}
				}

				for (int i = 0; i < posRequests.size(); i++) {
					delete posRequests[i];
				}
				for (int i = 0; i < interface->positionChanges.size(); i++) {
					delete interface->positionChanges[i];
				}
				posRequests.clear();
				interface->positionChanges.erase(interface->positionChanges.begin(), interface->positionChanges.begin() + posRequests.size());
			}
		}
		for (int i = 0; i < objects.size(); i++) {
			delete objects[i];
		}
		objects.clear();
	}

	//lol ok we are good to go, lets do this
	std::cout << materials->size() << std::endl;
	for (int i = 0; i < materials->size(); i++) {
		std::cout << "deleted1" << std::endl;
		delete (*materials)[i];
		std::cout << "deleted2" << std::endl;
	}
	materials->clear();
	delete materials;

	std::cout << "run:[INFO]: OpenGL terminated" << std::endl;
	//destroy IMGUI
	ImGui_ImplGlfwGL3_Shutdown();
	ImGui::DestroyContext();
	//Destroy window:
	glfwDestroyWindow(window);
	//DESTROY GLFW
	glfwTerminate();

	return 0;
}