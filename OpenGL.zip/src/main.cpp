#include <thread>
#include <iostream>
#include <chrono>
#include <time.h>
#include <thread>
#include <unordered_map>
#include <fstream>

#define _CRTDBG_MAP_ALLOC  
#include <stdlib.h>  
#include <crtdbg.h> 

#include "Application.h"
#include "Ship.h"

#ifdef _DEBUG
#define DBG_NEW new ( _NORMAL_BLOCK , __FILE__ , __LINE__ )
// Replace _NORMAL_BLOCK with _CLIENT_BLOCK if you want the
// allocations to be of _CLIENT_BLOCK type
#else
#define DBG_NEW new
#endif

void threadSync(ThreadInterface* interface, int syncType, int syncRate, long long microseconds, long long nanoseconds, bool trueNano) {
	if (syncType != interface->syncType) {
		interface->syncType == syncType;
	}
	if (interface->syncType == SYNC_FRAMERATE) {
		bool current = interface->frame;
		while (true) {
			if (current != interface->frame || interface->quit) break;
		}
	}
	else if (interface->syncType == SYNC_RATE) {
		if (trueNano) {
			long t = 1000000000 / syncRate;
			std::chrono::nanoseconds dura(t - nanoseconds);
			std::this_thread::sleep_for(dura);
		}
		else {
			int t = 1000000 / syncRate;
			std::chrono::microseconds dura(t - microseconds);
			std::this_thread::sleep_for(dura);
		}
	}
}

void syncThreads(ThreadInterface* interface) {
	std::cout << "[WARN]::[INFO]::This function is depricated, please use threadSync" << std::endl;
	bool current = interface->frame;
	while (true) {
		if (current != interface->frame || interface->quit) break;
	}
}

//redo this garbage

//------------------------------------\/DEPRICATED\/----------------------------------
class PhysicsObject {
public:
	int m_GraphicsID = 0;
	double x = 0;
	double y = 0;
	double vx = 0;
	double vy = 0;
	double r = 0;
	double rad = 0;
	double mass = 0;
	PhysicsObject(int ID, double x, double y, double vx, double vy, double r, double rad, double mass) : m_GraphicsID(ID), x(x), y(y), vx(vx), vy(vy), r(r), rad(rad), mass(mass) {}
};

void createPhysicsObject(double x, double y, double vx, double vy, double r, double rad, double mass, ThreadInterface* interface, std::vector<PhysicsObject*>& physObjs, int textureID) {
	CreateGraphicsObjectRequest* request = new CreateGraphicsObjectRequest(interface->generateNewObjectID(), textureID);

	PhysicsObject* obj = new PhysicsObject(request->ID, x, y, vx, vy, r, rad, mass);

	physObjs.emplace_back(obj);
	interface->createRequests.emplace_back(request);
}

void createGraphicsObject(ThreadInterface* interface, int textureID) {
	CreateGraphicsObjectRequest* request = new CreateGraphicsObjectRequest(interface->generateNewObjectID(), textureID);
	interface->createRequests.emplace_back(request);
}

void sendAllPosChangeRequests(ThreadInterface* interface, std::vector<PhysicsObject*>& physObjs) {
	if (interface->positionChanges.size() == 0) {
		for (PhysicsObject* obj : physObjs) {
			PosChangeRequest* pos = new PosChangeRequest(obj->m_GraphicsID, obj->x, obj->y, obj->r);
			interface->positionChanges.emplace_back(pos);
		}
	}
}

std::vector<std::vector<PhysicsObject*>*>* parrallelVectorSplitter(std::vector<PhysicsObject*>* objs, int threadCount) {
	std::vector<std::vector<PhysicsObject*>*>* vectors = new std::vector<std::vector<PhysicsObject*>*>;
	int threads = threadCount;
	if (objs->size() < threadCount) {
		threads = objs->size();
	}
	for (int i = 0; i < threads; i++) {
		vectors->emplace_back();
	}
	//std::cout << vectors->size() << "size" << std::endl;
	for (int i = 0; i < objs->size(); i++) {
		int pos = i % threads;
		(*vectors)[pos]->emplace_back((*objs)[i]);
	}
	return vectors;
}
//------------------------------------/\DEPRICATED/\----------------------------------

//============================================================================================================================================================================================================
//WRITE YOUR CODE HERE \/

void startup(ThreadInterface* interface) {

}

void process(ThreadInterface* interface) {
	std::string file("res/textures/blocks.txt");
	ShipBase loader;
	loader.parseShips(file);

	unsigned concurentThreadsSupported = std::thread::hardware_concurrency();
	int usableThreads = int(concurentThreadsSupported) - 2;
	std::cout << "[INFO]::[INFO]::Usable threads discovered: " << usableThreads << std::endl;

	int logicalTimeLock = 100;

	double logicScale = 1.0 / (double)logicalTimeLock;

	while (!interface->quit) {
		auto start2 = std::chrono::high_resolution_clock::now();
		auto start = std::chrono::high_resolution_clock::now();
		/*CODE GOES IN HERE*/
		
		/*-----------------*/
		/* \/ time logic here \/ */
		auto elapsed = std::chrono::high_resolution_clock::now() - start;

		long long microseconds = std::chrono::duration_cast<std::chrono::microseconds>(elapsed).count();
		long long nanoseconds = std::chrono::duration_cast<std::chrono::nanoseconds>(elapsed).count();

		/*std::cout << microseconds << std::endl;
		std::cout << std::chrono::duration_cast<std::chrono::nanoseconds>(elapsed).count() << "ns\n";*/
		
		/*long t = 1000000000 / logicalTimeLock;
		std::cout << nanoseconds << " " << t << " " << (t - nanoseconds) << std::endl;*/
		
		//this functin appears to take 200ns \/
		threadSync(interface, SYNC_RATE, logicalTimeLock, microseconds, nanoseconds, false);
		auto elapsed2 = std::chrono::high_resolution_clock::now() - start2;
		long long nanoseconds2 = std::chrono::duration_cast<std::chrono::nanoseconds>(elapsed2).count();
		std::cout << 1000000000 / nanoseconds2 << std::endl;
	}
}

//WRITE YOUR CODE HERE /\
//============================================================================================================================================================================================================

int main() {
	{
		ThreadInterface interface;

		startup(&interface);

		std::thread graphics(graphicsThread, 960, 540, &interface);
		std::thread process(process, &interface);

		//this is our quiting function \/ it waits till the window quits out to quit the process
		graphics.join();
		interface.quit = true;
		process.join();
	}
	_CrtDumpMemoryLeaks();

	return 0;
}