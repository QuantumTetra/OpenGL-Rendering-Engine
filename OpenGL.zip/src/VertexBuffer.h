#pragma once

class VertexBuffer {
private:
	unsigned m_RendererID;
public:
	VertexBuffer() {}
	VertexBuffer(const void* data, unsigned int size);
	~VertexBuffer();

	void PrintID();
	void Bind() const;
	void Unbind() const;
};