#include "Ship.h"

#include <fstream>
#include <iostream>

std::vector<std::string*>* parseFile(std::string& file) {
	std::ifstream inFile(file.c_str());
	if (!inFile) {
		std::cout << file << " failed" << std::endl;
		return nullptr;
	}
	//std::cout << "WORKED" << std::endl;
	std::vector<std::string*>* text = new std::vector<std::string*>;
	// one line
	//std::string line;
	char data[100];
	// extract all the text from the input file
	//std::cout << "FILE SUCCESS" << std::endl;
	while (inFile.getline(data, 100)) {
		// store each line in the vector
		std::string* texts = new std::string(data);
		//std::cout << *texts << std::endl;
		text->emplace_back(texts);
	}
	return text;
}


std::vector<ShipBase*>* ShipBase::parseShips(std::string& file) const {
	ShipBase deleter;
	std::vector<ShipBase*>* ships = new std::vector<ShipBase*>;
	std::vector<std::string*>* strings = parseFile(file);
	
	//test

	int stringStep = 0;
	int stringMax = strings->size();

	for (stringStep = 0; stringStep < stringMax; stringStep++) {
		std::cout << *(*strings)[stringStep] << std::endl;
	}
	




	if (strings != nullptr) {
		for (int i = 0; i < strings->size(); i++) {
			delete (*strings)[i];
		}
		delete strings;
	}

	deleter.deleteShipVector(ships);

	return nullptr;
}