#pragma once
#include "ThreadInterface.h"

int graphicsThread(int width, int height, ThreadInterface* Interface);