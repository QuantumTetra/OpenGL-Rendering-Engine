#pragma once
#include <vector>

#define SYNC_FRAMERATE 0
#define SYNC_RATE 1
#define SYNC_NONE 2

class CreateGraphicsObjectRequest {
public:
	int ID;
	float scale = 1.0f;
	int textureID = 0;
	CreateGraphicsObjectRequest(int objectID, int textureID) : ID(objectID), textureID(textureID) {}
	CreateGraphicsObjectRequest(int objectID, float scale, int textureID) : ID(objectID), scale(scale), textureID(textureID) {}
};

class PosChangeRequest {
public:
	int ID;
	double x;
	double y;
	double r;
	PosChangeRequest(int LinkID, double x, double y, double r) : ID(LinkID), x(x), y(y), r(r) {}
};

class ThreadInterface {
public:
	int objectID = 0;
	bool frame = false;
	int syncType = 2;
	bool quit = false;

	std::vector<PosChangeRequest*> positionChanges;
	std::vector<CreateGraphicsObjectRequest*> createRequests;

	int generateNewObjectID() {
		objectID++;
		return objectID;
	}
	~ThreadInterface() {
		for (int i = 0; i < positionChanges.size(); i++) {
			delete positionChanges[i];
		}
		positionChanges.clear();
		for (int i = 0; i < createRequests.size(); i++) {
			delete createRequests[i];
		}
		createRequests.clear();
	}
};